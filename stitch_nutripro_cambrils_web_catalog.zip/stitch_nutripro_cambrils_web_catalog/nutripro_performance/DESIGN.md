---
name: Nutripro Performance
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1b1b1b'
  surface-container: '#1f1f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353535'
  on-surface: '#e2e2e2'
  on-surface-variant: '#ebbbb4'
  inverse-surface: '#e2e2e2'
  inverse-on-surface: '#303030'
  outline: '#b18780'
  outline-variant: '#603e39'
  surface-tint: '#ffb4a8'
  primary: '#ffb4a8'
  on-primary: '#690100'
  primary-container: '#ff5540'
  on-primary-container: '#5c0000'
  inverse-primary: '#c00100'
  secondary: '#b8c8da'
  on-secondary: '#223240'
  secondary-container: '#394857'
  on-secondary-container: '#a7b7c8'
  tertiary: '#acc7ff'
  on-tertiary: '#002f67'
  tertiary-container: '#488fff'
  on-tertiary-container: '#00285b'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad4'
  primary-fixed-dim: '#ffb4a8'
  on-primary-fixed: '#410000'
  on-primary-fixed-variant: '#930100'
  secondary-fixed: '#d4e4f6'
  secondary-fixed-dim: '#b8c8da'
  on-secondary-fixed: '#0d1d2a'
  on-secondary-fixed-variant: '#394857'
  tertiary-fixed: '#d7e2ff'
  tertiary-fixed-dim: '#acc7ff'
  on-tertiary-fixed: '#001a40'
  on-tertiary-fixed-variant: '#004491'
  background: '#131313'
  on-background: '#e2e2e2'
  surface-variant: '#353535'
typography:
  display-lg:
    fontFamily: Montserrat
    fontSize: 72px
    fontWeight: '900'
    lineHeight: 72px
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Montserrat
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 52px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Montserrat
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Montserrat
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-bold:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 20px
    letterSpacing: 0.05em
spacing:
  base-unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style
The design system is engineered to evoke the high-intensity atmosphere of a premium, traditional strength-training facility. It targets serious athletes and fitness enthusiasts in Cambrils who value discipline and performance. 

The visual style is a fusion of **Modern Minimalism** and **High-Contrast Boldness**. It utilizes a "dark mode by default" philosophy to create a focused, "gritty" environment. The aesthetic relies on aggressive typography, raw black-and-white photography with high clarity, and a "Critical Red" accent to direct attention toward action-oriented elements. The emotional response should be one of immediate urgency and professional-grade reliability.

## Colors
The palette is dominated by **Deep Black (#000000)** to represent the "iron" and the gym floor. **Critical Red (#FF0000)** is used exclusively for primary actions, status indicators, and energetic highlights. 

**Slate Grey (#708090)** serves as a functional secondary color for borders, disabled states, and subtle iconography, preventing the UI from feeling overly flat. **Surface Black (#0F0F0F)** is used for cards and containers to create subtle separation from the pure black background. All text defaults to **Pure White** to ensure maximum legibility against the dark canvas.

## Typography
The typographic hierarchy is designed to be "loud." **Montserrat** is the engine for all headlines, set in heavy weights (ExtraBold/Black) with tight letter spacing and mandatory uppercase transformations to mimic athletic branding and gym signage.

**Inter** provides a highly legible, utilitarian counterpoint for body copy and data-heavy catalogs. It remains neutral to ensure that the intensity of the headlines is not diluted. For mobile, display sizes are scaled aggressively to maintain impact without breaking layouts.

## Layout & Spacing
This design system employs a **Fixed Grid** model for desktop to maintain a structured, editorial feel, transitioning to a fluid model for mobile devices. 

- **Desktop:** 12-column grid with a 1280px max-width.
- **Gutter/Margins:** Large 24px gutters provide breathing room between high-contrast elements, preventing visual clutter. 
- **Rhythm:** All spacing (padding, margins) must be multiples of the 8px base unit. 
- **Catalogs:** Product and gallery grids should utilize a strict square aspect ratio for thumbnails to reinforce the structured, professional aesthetic.

## Elevation & Depth
In alignment with the "gritty" and "premium" narrative, depth is achieved through **Low-contrast outlines** rather than soft shadows. 

- **Surfaces:** Containers use `#0F0F0F` (Surface Black) to sit slightly above the `#000000` base.
- **Borders:** Subtle 1px borders using `#333333` or Slate Grey are preferred over shadows to define card edges.
- **Interactive States:** On hover or focus, elements should not "float" higher; instead, they should trigger a color shift (e.g., border turning Red) or a slight scale-up effect to maintain a grounded, industrial feel.

## Shapes
The shape language is **Sharp (0px)**. 

To reinforce the traditional gym and "iron" metaphor, all buttons, cards, input fields, and image containers must have 90-degree corners. This lack of rounding conveys strength, precision, and an uncompromising professional attitude. Pill shapes are strictly forbidden, even for tags or chips.

## Components
- **Buttons:** Primary buttons feature a Critical Red background with White Bold Uppercase text. Hover states should invert the colors or darken the red. No gradients.
- **Cards:** Dark Surface (#0F0F0F) with a 1px Slate Grey border. Used for product catalogs, trainer bios, and workout plans.
- **Inputs:** Square-edged text fields with black backgrounds and white borders. Focus state triggers a Red border.
- **Lists:** High-density lists with Critical Red bullet points or icons. 
- **Chips/Tags:** Rectangular boxes with Slate Grey borders and uppercase label-font text.
- **Progress Bars:** For "Goals" or "Training Load," use a solid Red fill against a Slate Grey track. No rounded caps.
- **Data Tables:** High-contrast rows with thin dividers; header text must be `label-bold`.